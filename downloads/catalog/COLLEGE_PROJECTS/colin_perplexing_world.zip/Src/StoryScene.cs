﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class StoryScene
    {
        // Variables for the prologue
        private static string scene0 = @"                   Prologue
        .                      .
.               .          (\(\(\
                          @@@@@@@@        .
         .             @@@@@@@@@@@@@@@
                    @@@@@@@@@@@@@@@@@@@@@
              .   @@@@@@@@█@@@@@@@@@@@@@@@@@
     .         @@@@@@@@@@@@@@@@@@@@@@@@@@@█@@
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      @@@@@@@@@@@@@@@@@@@@@@@█@@@@@@@@@@@@@@@
    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@█@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@█@";

        private static string scene1 = @"                   Prologue
     .                                       
                                             
                              .              
  /              ______________           /  
              __/@@@@@@@@@@@@@@@\_          
     .        @@@@@@@@@@@@@@@@@@@@          
                 @@@@@@@@@@@@@@        .    
                              ##########     
                             #WELCOME TO#    
           .                 #FUN LANDZ!#  
                             ############   |
                                  ##  .      
                  \               ##         
";

        private static string scene2 = @"                   Prologue
     .                                       
                                             
         HELP ME!!!           .              
  /              ______________           /  
              __/@@@@@@@@@@@@@@@\_          
     .        @@@@@@@@@@@@@@@@@@@@          
                 @@@@@@@@@@@@@@        .    
                              ##########     
                             #WELCOME TO#    
           .                 #FUN LANDZ!#  
                             ############   |
                                  ##  .      
                  \               ##         
";

        /*
         * The first letter represents:
         * "T" (Text) - Dialogue
         * "S" (Scene) - A cutscene image (must have the width of 45, height of 15)
         */
        private static string[][] storyScript = [
            [ "S", scene0 ],
            [ "T", "Two friends wonder around the park\nwhile chatting about their own hobbies." ],
            [ "T", "The names of those said friends\nare \"Colin\" and \"Toby\"." ],
            [ "T", "Meanwhile they are confronted with an\nunusual looking hill that was very steep." ],
            [ "T", "Toby had asked Colin,\n\"Say, you wanna climb up there?\"" ],
            [ "T", "Colin decided to do so,\nand off they were to a 10 minute climb." ],

            [ "S", scene1 ],
            [ "T", "Toby had finally made it to the\ntop of the hill and was met with a hole." ],
            [ "T", "And a totally not so sketchy sign\nthat reads out \"Welcome to Fun Landz!\"" ],
            [ "T", "He was curious to enter in but a hand\nreaches out and grabbed him to the hole!" ],
            [ "S", scene2 ],
            [ "T", "And so he was into the hole with an\necho shouting for help." ],
            [ "S", scene1 ],
            [ "T", "Colin had then just made it and\nsees the same hole."],
            [ "T", "However, it did not grab him into it,\nbut he was still curious what awaits." ],
            [ "T", "He jumped into the hole and had\nfallen for hours..." ],
            [ "T", "And so the game begins..." ],
        ];

        public static string[][] Script { get { return storyScript; } }
    }
}
