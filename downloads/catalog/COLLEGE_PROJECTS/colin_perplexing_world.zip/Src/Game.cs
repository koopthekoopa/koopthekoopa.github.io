﻿using System;
using System.Diagnostics;
using System.Net.Security;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Reflection;

/**
 *  PROGRESS:
 *  
 * 1. Writing a fancy engine of printing text/ASCII art.
 */

namespace ProjRPG
{
    class Game
    {
        // "ConsoleEx" is a fancy thing that I've written (see "ConsoleEx.cs")
        public static void TextBoxDo(string[] script, int lines = 2)
        {
            int textX = 3;
            int textY = Screen.Height - 4;

            int textLength = 41;
            int textLines = lines;

            // Display a nice little border.
            Console.ForegroundColor = ConsoleColor.Cyan;
            ConsoleEx.WriteSquare(textX - 1, textY - 1, textLength, textLines);

            for (int i = 0; i < script.Length; i++)
            {
                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                ConsoleEx.CreateSkipThread();

                ConsoleEx.Write(script[i], 40, textX, textY, ConsoleColor.Yellow);
                while (ConsoleEx.Skipped == false) { }

                ConsoleEx.RevertSkipThread();
            }
            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
        }
        public static void StorySceneRun(string[][] script)
        {
            int sceneX = 1;
            int sceneY = 1;

            int sceneWidth = 45;
            int sceneHeight = 15;

            int textX = 3;
            int textY = Screen.Height - 3;

            int textLength = 41;
            int textLines = 2;

            // Display a nice little border.
            Console.ForegroundColor = ConsoleColor.Cyan;
            ConsoleEx.WriteSquare(textX - 1, textY - 1, textLength, textLines);

            // Note the user that they won't get bored.
            ConsoleEx.Write("Press ENTER to skip.", 0, 2, Screen.Height, ConsoleColor.Green);

            // Add a thread that makes us skip when pressing the "skip key" (enter key)
            ConsoleEx.CreateSkipThread();

            for (int i = 0; i < script.Length; i++)
            {
                // if it is a cutscene image, draw it
                if (script[i][0] == "S")
                {
                    ConsoleEx.ClearRect(sceneX, sceneY, sceneWidth, sceneHeight);
                    ConsoleEx.Write(script[i][1], 0, sceneX, sceneY, ConsoleColor.White);
                }
                // if it is dialogue, type it out
                else if (script[i][0] == "T")
                {
                    ConsoleEx.Write(script[i][1], 100, textX, textY, ConsoleColor.Yellow);
                    ConsoleEx.Sleep(2600);
                }
                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                // If we press the "skip key", stop the story
                if (ConsoleEx.Skipped) break;
            }

            // And revert the state to make it type in the text again
            ConsoleEx.RevertSkipThread();

            // Done story
            Screen.Clear();
        }

        // The main function
        public static void Main(string[] args)
        {
            Console.Title = "COLIN IN THE PERPLEXING WORLD";

            ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
            Screen.Init(45, 20);
            Console.ResetColor();

            // Story
            StorySceneRun(StoryScene.Script);

            TitleScene title = new TitleScene();
            while (true) {
                Screen.Clear();

                title.Run();

                switch(title.Choice)
                {
                    // Start game
                    case 0:
                        {
                            GameLoop();
                            break;
                        }
                    // How do I play?
                    case 1:
                        {
                            Manual manual = new Manual();
                            manual.Run();
                            manual = null;
                            break;
                        }
                    // Credits
                    case 2:
                        {
                            Credits credits = new Credits();
                            credits.Run();
                            credits = null;
                            break;
                        }
                    // Exit Game
                    case 3:
                        {
                            Screen.Clear();
                            ConsoleEx.ForegroundColor = ConsoleColor.Green;
                            ConsoleEx.Write("See you later!", 50, 16, 10);

                            Screen.MoveCursorBelow();
                            Console.ResetColor();
                            Environment.Exit(0);
                            break;
                        }
                }
            }
        }

        private static string scene0 = @"                                @@          
                               #@@          
                              (@ @          
                             @@  @          
                           @@    @          
                         @,     @@          
                         @     (@           
                        @&    %@            
                       @@    @&             
                      @.   @@               
                    @@  ,@#                 
              @@@(@, @@*                    
              %@@ @@                        
           .@# ,@@@@                        
           @ @@                            ";

        private static string[][] scriptBegin = [
            [ "S", scene0 ],
            [ "T", "You are greeted with a spotlight that\nshows a wooden sword." ],
            [ "T", "You then decided to pick up that sword\nand as you do, the world reveals itself." ],
            [ "T", "And you are then prepared for what\nthe world awaits..." ],
        ];

        private static string epilogueImage = @"
                                            
                   ##########              
                 ##############            
                   ##########              
                  ............             
                  ............             
                 ..............            
                 ..............            
                ................           
                ................           
               ..................          
               ..................          
              ....................         
              ....................         ";

        private static string[][] epilogueScript = [
            ["S", epilogueImage],
            ["T", "And so... After Colin had defeated\nthe king and had saved Toby,"],
            ["T", "They both go onto the \n\"trampoline and jumped out of here!"],
            ["T", "And this point Toby was thanking\nalot how Colin saved his life."],
            ["T", "Colin made sure that Toby should\nbe aware more. And our story concludes..."],
        ];

        private static string theEndImage = @"  _______ _          
 |__   __| |         
    | |  | |__   ___ 
    | |  | '_ \ / _ \
    | |  | | | |  __/
  __|_|_ |_| |_|\___|
 |  ____|         | |
 | |__   _ __   __| |
 |  __| | '_ \ / _` |
 | |____| | | | (_| |
 |______|_| |_|\__,_|";

        // WHERE THE GAME CODE BELONGS

        public static Weapon[] weapons;
        public static PotionID[] potions;
        public static int Money = 0;
        public static int StarPieces = 0;
        public static int MaxStarPieces = 4;
        public static int enemiesKilled = 0;

        public static void RemovePotion(int id)
        {
            List<PotionID> a = new List<PotionID>(potions);
            a.RemoveAt(id);
            a.Add(null);
            potions = a.ToArray();
        }

        public static bool HasPotion(PotionID potion)
        {
            for (int i = 0; i < potions.Length; i++)
            {
                if (potions[i] != null)
                {
                    if (potions[i] == potion)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static void AddStarPiece()
        {
            if (StarPieces < MaxStarPieces) StarPieces++;
            TextBoxDo(["You have got a Star piece!"]);
            if (StarPieces >= MaxStarPieces)
            {
                TextBoxDo(["You have gotten all of the Star pieces!",
                            "Now you can talk to those guards\nblocking the gate to the King.",
                            "It's best top grind some wild enemies\nto get stronger..."]);
            }
            else
            {
                TextBoxDo(["Just need " + (MaxStarPieces - StarPieces) + " more to advance through\nthe gate that leads to the king!"]);
            }
        }

        private static void GameLoop()
        {
            StarPieces = 0;
            Money = 1400;
            enemiesKilled = 0;

            // Prepare the Game
            Screen.Clear();

            // Getting sword scene
            StorySceneRun(scriptBegin);

            // Prepare weapon for Player
            weapons = new Weapon[3];
            for (int i = 0; i < weapons.Length; i++)
            {
                weapons[i] = null;
            }
            weapons[0] = Weapons.WoodenSword;

            // Prepare potions for Player
            potions = new PotionID[3];

            Map.Init();

            TimeSpan before = DateTime.Now.TimeOfDay;

            Map.Prepare(Maps.entrance);
            Map.Run();

            TimeSpan after = DateTime.Now.TimeOfDay;

            StorySceneRun(epilogueScript);

            ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
            ConsoleEx.WriteLine(theEndImage, 0, 12, 4, ConsoleColor.Yellow);
            ConsoleEx.WriteLine("Enemies Defeated: " + enemiesKilled, 0, 12, 16);
            ConsoleEx.WriteLine("Time taken to beat: " + (int)(after.TotalMinutes - before.TotalMinutes) + " minutes, " + (int)(after.TotalSeconds - before.TotalSeconds) + " seconds.", 0, 3, 17);

            ConsoleEx.ReadKey();

            Screen.Clear();

            // after the game

            //Battle.Do(Enemies.Guards);
        }
    }
}


