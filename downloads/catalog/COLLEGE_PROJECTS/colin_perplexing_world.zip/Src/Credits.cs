﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class Credits
    {
        private static string creditText = @"
 * The Internet - art that I wasn't bothered
   doing.
 * My brain - the work.
 * Joan G. Stark - Most ASCII art.


  Programs used:
    Visual Studio
    Microsoft Paint
    ASCII art converters";
        public void Run()
        {
            Screen.Clear();

            // dont get sued
            ConsoleEx.Write("CREDITS:", 0, 2, 2, ConsoleColor.Green);

            Console.ResetColor();
            ConsoleEx.Write(creditText, 0, 1, 4);

            ConsoleEx.Write("Press ENTER to go back to the menu.", 0, 2, 20, ConsoleColor.Green);

            // Wait til they pressed any button (this is my solution...... idk anymore)
            ConsoleEx.ReadKey();
        }
    }
}
