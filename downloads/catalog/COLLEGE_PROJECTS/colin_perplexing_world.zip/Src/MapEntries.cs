﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class MapEntry
    {
        public string name = "Undefined";
        public string[] mapLayout;
        public int width;
        public int height;
        public int startX;
        public int startY;
    }
    public static class Maps
    {
        public enum Name
        {
            PROLOGUE = 0,
            FIELD,
            KING,
            CAVERN,
            PUZZLE,
        };
        public enum FieldName
        {
            FIELD_BOTTOM = 0,
            FIELD_MIDDLE,
            FIELD_TOP,
        };
        public enum CaveName
        {
            CAVE_MIDDLE,
            CAVE_ARENA,
            CAVE_PUZZLE
        };
        public static MapEntry entrance = new MapEntry()
        {
            name = "The Entrance.",
            mapLayout = [
                "&&&&&&&&&&&&&&&#            #&&&&&&&&&&&&&&&&",
                "&&&&&&&&&&&&&&&#            #&&&&&&&&&&&&&&&&",
                "&&&&&&&&&&&&&&&#            #&&&&&&&&&&&&&&&&",
                "&&&&&&&&&&&&&&&#            #&&&&&&&&&&&&&&&&",
                "&&&&&&&&&&&&&&&#            #&&&&&&&&&&&&&&&&",
                "&&&&&&&&&&&&&&&#============#&&&&&&&&&&&&&&&&",
                "################     00     #################",
                "                                             ",
                "                                             ",
                "                                  .          ",
                "          .                                  ",
                "                                             ",
                "                                             ",
                "                         .                   ",
                "                                    .        ",
                "                                             ",
                "       .                                     ",
                "                                             ",
                "                                     .       ",
                "                                             ",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = 22,
            startY = 16,
        };
        public static MapEntry field0 = new MapEntry()
        {
            name = "Main Field (bottom)",
            mapLayout = [
                "##################         ##################",
                "# .                                         #",
                "#                                           #",
                "#                                           #",
                "#                               .           #",
                "#             .                             #",
                "#                                           #",
                "#                                           #",
                "#                                           #",
                "#                                 .         #",
                "#         .                                 #",
                "#                                           #",
                "#                                           #",
                "#                        .                  #",
                "#                                   .       #",
                "#                                           #",
                "#      .                                    #",
                "#                                           #",
                "#                                    .      #",
                "################=============################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry field1 = new MapEntry()
        {
            name = "Main Field (middle)",
            mapLayout = [
                "##################         ##################",
                "# .                                         #",
                "#                                           #",
                "#       ######                              #",
                "#      ########                 .           #",
                "#      ###==###                             #",
                "#                                           #",
                "                                             ",
                "                                             ",
                "                                  .          ",
                "          .                                  ",
                "                                             ",
                "                                             ",
                "#                        .                  #",
                "#                                   .       #",
                "#                                           #",
                "#      .                                    #",
                "#                                           #",
                "#                                    .      #",
                "##################         ##################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry field2 = new MapEntry()
        {
            name = "King's entrance.",
            mapLayout = [
                "#############################################",
                "# .                                         #",
                "#                                           #",
                "#                                           #",
                "#                               .           #",
                "#             .                             #",
                "#########===========================#########",
                "#                     00                    #",
                "#                                           #",
                "#                                 .         #",
                "#         .                                 #",
                "#                                           #",
                "#                                           #",
                "#                        .                  #",
                "#                                   .       #",
                "#                                           #",
                "#      .                                    #",
                "#                                           #",
                "#                                    .      #",
                "##################         ##################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry cavern0 = new MapEntry()
        {
            name = "Cavern (middle)",
            mapLayout = [
                "##################         ##################",
                "# .                                         #",
                "#             .                  .          #",
                "#                                           #",
                "#       #                                   #",
                "#       ##       ###                ###     #",
                "#                #####               #      #",
                "#                                            ",
                "#        .                .                  ",
                "#                  ###            .          ",
                "#         .         ##                       ",
                "#         #                 \"         ,      ",
                "#   .   ####   ,                             ",
                "#        ##              .         ##       #",
                "#                                   #       #",
                "#                            \"        .     #",
                "#      .  #       '                         #",
                "#                                           #",
                "#                      .                    #",
                "##################         ##################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry cavern1 = new MapEntry()
        {
            name = "Cavern (arena)",
            mapLayout = [
                "#############################################",
                "#                                           #",
                "#       .                              ###  #",
                "#                     0               ##### #",
                "#                       ,         .     ##  #",
                "#              ,                            #",
                "#    ##                                 #   #",
                "#   ###                               ####  #",
                "#                0                     ##   #",
                "#                 .                         #",
                "#                0          ,           ##  #",
                "#    ##                                 ### #",
                "#    ##                                     #",
                "#     #                             .    ## #",
                "#           ,       ,     ,                 #",
                "#                                       #,  #",
                "#      .  #                           ###   #",
                "#       ####                         ####   #",
                "#      #####                 .   ##         #",
                "##################         ##################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry cavern2 = new MapEntry()
        {
            name = "Cavern (puzzle)",
            mapLayout = [
                "##################         ##################",
                "#                                           #",
                "# .                       .                 #",
                "#   ####    ,                     #         #",
                "#   ###                         ####    .   #",
                "#    #     /                 /    ###       #",
                "#                   .                       #",
                "#                                           #",
                "#        .                      .           #",
                "#                        ,          #####   #",
                "#      ##                            ###    #",
                "#     ##### .                               #",
                "#      ####                                 #",
                "#        .              ,                   #",
                "#          /                 /              #",
                "#                        .                  #",
                "#    ,#####                             .   #",
                "#    ####        ,                          #",
                "#                                           #",
                "#############################################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry puzzleMap = new MapEntry()
        {
            name = "Puzzle time!!!",
            mapLayout = [
                "#############################################",
                "# .                                         #",
                "#                                           #",
                "#                                           #",
                "#                               .           #",
                "#             .                             #",
                "#                                           #",
                "                                            #",
                "                                            #",
                "                                  .    0    #",
                "          .                            0    #",
                "                                            #",
                "                                            #",
                "#                        .                  #",
                "#                                   .       #",
                "#                                           #",
                "#      .                                    #",
                "#                                           #",
                "#                                    .      #",
                "#############################################",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
        public static MapEntry theKing = new MapEntry()
        {
            name = "The King (finale)",
            mapLayout = [
                "#############################################",
                "# .            |            |        O      #",
                "#              |            |        O      #",
                "#              |            |        O      #",
                "#              |            |   .  #####    #",
                "#             .|            |      # O #    #",
                "#              |     0      |      #####    #",
                "#              |            |               #",
                "#               \\__________/                #",
                "#                __________       .    0    #",
                "#         .      __________            0    #",
                "#                                           #",
                "#                                           #",
                "#                        .       ######     #",
                "#                                ######     #",
                "#                                ##==##     #",
                "#      .                                    #",
                "#                                           #",
                "#                                    .      #",
                "#############                  ##############",
            ],
            width = Screen.Width,
            height = Screen.Height,
            startX = Screen.Width / 2,
            startY = Screen.Height - 2,
        };
    }
}
