﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    // These are IDs. The functionality is in Battle.cs
    public class PotionID
    {
        public string name = "undefined";
        public int time = 5;
    }
    public static class PotionIDs
    {
        public static PotionID Weak = new PotionID
        {
            name = "Potion of Weakness",
        };
        public static PotionID Distract = new PotionID
        {
            name = "Potion of Distraction",
        };
        public static PotionID Heal = new PotionID
        {
            name = "Potion of Healing",
            time = 0
        };
    }
}
