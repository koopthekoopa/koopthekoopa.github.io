﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ProjRPG
{
    public static class Battle
    {
        static string gmoverGfx = @"
   _____          __  __ ______ 
  / ____|   /\   |  \/  |  ____|
 | |  __   /  \  | \  / | |__   
 | | |_ | / /\ \ | |\/| |  __|  
 | |__| |/ ____ \| |  | | |____ 
  \_____/_/    \_\_|__|_|______|
  / __ \ \    / /  ____|  __ \  
 | |  | \ \  / /| |__  | |__) | 
 | |  | |\ \/ / |  __| |  _  /  
 | |__| | \  /  | |____| | \ \  
  \____/   \/   |______|_|  \_\ ";
        static int textX = 3;
        static int textY = Screen.Height - 4;

        static int textLength = 41;
        static int textLines = 4;

        public static int userHealth = 100;
        public static int userMaxHealth = userHealth;
        public static int userExp = 0;
        public static int userLevel = 1;
        public static int userChance = 0;

        public static bool prevMissed = false;

        static void displayHealth(int curHealth, int maxHealth, int posx, int posy)
        {
            ConsoleColor prev = ConsoleEx.ForegroundColor;

            // Clear the health bar
            ConsoleEx.ClearRect(posx, posy, 18, 1);
            ConsoleEx.ClearRect(posx+4, posy+1, 10, 1);

            // Draw text
            ConsoleEx.Write("Health: " + (curHealth > 0 ? curHealth : 0) + " / " + maxHealth, 0, posx, posy, ConsoleColor.White);

            // Calculate the bar
            float percent = (float)Math.Abs((float)curHealth / (float)maxHealth * 100f);
            int healthBar = curHealth > 0 ? (int)Math.Ceiling(percent / 10f) : 0;

            // Decide bar colour
            ConsoleColor healthColor;
            if (percent <= 33)
            {
                healthColor = ConsoleColor.Red;
            }
            else if (percent <= 66)
            {
                healthColor = ConsoleColor.Yellow;
            }
            else
            {
                healthColor = ConsoleColor.Green;
            }

            // Create bar
            StringBuilder healthBarStr = new StringBuilder();
            for (int i = 0; i < healthBar; i++)
            {
                healthBarStr.Append("#");
            }
            
            // Draw bar
            ConsoleEx.Write(healthBarStr.ToString(), 0, posx+4, posy+1, healthColor);

            ConsoleEx.ForegroundColor = prev;
        }

        public static string getName(Enemy enemy, bool cap = true)
        {
            // Funny
            if (cap)
            {
                return (enemy.wild ? "The " + enemy.name : enemy.name);
            }
            else
            {
                return (enemy.wild ? "the " + enemy.name : enemy.name);
            }
        }

        public static string getNameAlt(Enemy enemy, bool cap = true)
        {
            // Funny (deluxe edition)
            if (cap)
            {
                return (enemy.wild ? "A " + enemy.name : enemy.name);
            }
            else
            {
                return (enemy.wild ? "A " + enemy.name : enemy.name);
            }
        }

        private static int WEAK_TIMER = 5;
        private static int DISTRACT_TIMER = 5;
        private static int weakTick = 0;
        private static int distractTick = 0;
        public static int Do(Enemy enemy)
        {
            weakTick = 0;
            distractTick = 0;

            prevMissed = false;
            bool fin = false;
            int currentHealth = enemy.health;
            int oldHealth = userHealth;

            // In battle loop (if the user won, make sure they break out of it
            while (true)
            {
                int currentXp = 0;
                Screen.Clear();

                // Display the enemy
                ConsoleEx.Write(enemy.art, 0, 11, 3, ConsoleColor.White);
                ConsoleEx.Write(getNameAlt(enemy), 0, 4, 1, ConsoleColor.White);

                // Init health bars
                displayHealth(userHealth, userMaxHealth, 2, 13);
                displayHealth(currentHealth, enemy.health, 28, 1);

                // Display a nice little border.
                ConsoleEx.ForegroundColor = ConsoleColor.Cyan;
                ConsoleEx.WriteSquare(textX - 1, textY - 1, textLength, textLines);

                // They wanna battle!!!
                //ConsoleEx.CreateSkipThread();
                if (enemy.wild)
                {
                    ConsoleEx.Write("A wild " + enemy.name + " has appeared!", 40, textX, textY, ConsoleColor.White);
                }
                else
                {
                    ConsoleEx.Write(enemy.name + " wants to battle!", 40, textX, textY, ConsoleColor.White);
                }
                ConsoleEx.Sleep(1100);
                //ConsoleEx.RevertSkipThread();
                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                // Battle it!
                while (fin == false)
                {
                    bool wasAttacking = false;

                    Random rng = new Random();
                    // Choose your attack style
                    ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
                    int choice = ConsoleEx.Choice(["Weapon", "Magic", "Run"], textX + 1, textY);
                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                    // Attack
                    if (choice == 0)
                    {
                        List<string> weaponChoice = new List<string>();
                        int i = 0;
                        for (i = 0; i < Game.weapons.Length; i++)
                        {
                            //Console.Write("is entry {0} null?", i);
                            if (Game.weapons[i] == null)
                            {
                                //Console.WriteLine(" yes");
                                break;
                            }
                            weaponChoice.Add(Game.weapons[i].name);
                        }
                        int backIdx = i;
                        weaponChoice.Add("Back");

                        // If no weapons available
                        if (backIdx == 0)
                        {
                            // It aint possible bro
                            Screen.MoveCursorBelow();
                            throw new Exception("Player must have a weapon.");
                        }

                        // Choose yo option
                        ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
                        choice = ConsoleEx.Choice(weaponChoice.ToArray(), textX + 1, textY);
                        ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                        // If they pressed back
                        if (choice == backIdx)
                        {
                            continue;
                        }
                        else
                        {
                            wasAttacking = true;
                            // Player's turn
                            ConsoleEx.Write("You have chosen to use\n" + Game.weapons[choice].name + "!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                            bool chance = rng.NextDouble() <= (Game.weapons[choice].criticalChance) + (float)(userChance * 0.1);
                            int prevHealth = currentHealth;
                            
                            // Did they miss?
                            if (rng.NextDouble() <= Game.weapons[choice].missChance && !prevMissed)
                            {
                                prevMissed = true;
                                // yes (HAHA)
                                ConsoleEx.Write("But you have missed.\n", 40, textX, textY, ConsoleColor.White);
                                ConsoleEx.Sleep(1500);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            }
                            else
                            {
                                if (prevMissed)
                                {
                                    prevMissed = false;
                                }
                                // Damage
                                currentHealth -= (int)(Math.Ceiling(chance ? (double)(Game.weapons[choice].damage * Game.weapons[choice].criticalDamage) : Game.weapons[choice].damage));

                                // Refresh health
                                displayHealth(currentHealth, enemy.health, 28, 1);

                                // Give 'em XP
                                currentXp += ((prevHealth - currentHealth) / 2) + 3;
                                if (currentHealth <= 0)
                                {
                                    currentXp += 3;
                                }

                                // Tell 'em
                                ConsoleEx.Write("You have dealt " + (prevHealth - currentHealth) + " damage!", 40, textX, textY, ConsoleColor.White);
                                if (chance) ConsoleEx.Write("Critical Hit!", 40, textX, textY + 1, ConsoleColor.Green);
                                ConsoleEx.Sleep(1500);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            }
                            // Enemy's turn!!!!!
                            if (currentHealth > 0)
                            {
                                int oppWeap = rng.Next(0, enemy.weapons.Length);
                                ConsoleEx.Write(getName(enemy) + " has chosen to use\n" + enemy.weapons[oppWeap].name + "!", 40, textX, textY, ConsoleColor.White);
                                ConsoleEx.Sleep(1500);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                // Did they miss?
                                if (rng.NextDouble() <= (enemy.weapons[oppWeap].missChance * (enemy.isDistract ? 2 : 1)))
                                {
                                    // yes (NOOO)
                                    ConsoleEx.Write("But they have missed.\n", 40, textX, textY, ConsoleColor.White);
                                    ConsoleEx.Sleep(1500);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                                }
                                else
                                {
                                    // Their attack
                                    chance = rng.NextDouble() <= Game.weapons[choice].criticalChance;
                                    prevHealth = userHealth;
                                    int attackDamage = (int)(Math.Ceiling(chance && !enemy.isDistract ? (double)(enemy.weapons[oppWeap].damage * enemy.weapons[oppWeap].criticalDamage) : enemy.weapons[oppWeap].damage));
                                    if (enemy.isWeak) attackDamage = attackDamage / 2;
                                    userHealth -= attackDamage;

                                    displayHealth(userHealth, userMaxHealth, 2, 13);

                                    // LOSE XP?!!
                                    currentXp -= (prevHealth - userHealth) / 2;

                                    // Tell 'em unfortunate news to the player
                                    ConsoleEx.Write("They have dealt " + (prevHealth - userHealth) + " damage!", 40, textX, textY, ConsoleColor.White);
                                    if (chance && !enemy.isDistract) ConsoleEx.Write("Critical Hit!", 40, textX, textY + 1, ConsoleColor.Red);
                                    ConsoleEx.Sleep(1500);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                                }
                            }
                        }
                    }
                    // Potion
                    else if (choice == 1)
                    {
                        // TODO
                        List<string> potionChoice = new List<string>();
                        int i = 0;
                        for (i = 0; i < Game.potions.Length; i++)
                        {
                            //Console.Write("is entry {0} null?", i);
                            if (Game.potions[i] == null)
                            {
                                //Console.WriteLine(" yes");
                                break;
                            }
                            potionChoice.Add(Game.potions[i].name);
                        }
                        int backIdx = i;
                        potionChoice.Add("Back");

                        if (backIdx == 0)
                        {
                            ConsoleEx.Write("You do not have any potions!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                        }
                        else
                        {
                            ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
                            choice = ConsoleEx.Choice(potionChoice.ToArray(), textX + 1, textY);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                            // If they pressed back
                            if (choice == backIdx)
                            {
                                continue;
                            }
                            else
                            {
                                ConsoleEx.Write("You have chosen to use\n" + Game.potions[choice].name + "!", 40, textX, textY, ConsoleColor.White);
                                ConsoleEx.Sleep(1500);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                if (Game.potions[choice].name == PotionIDs.Heal.name)
                                {
                                    userHealth += 30;
                                    if (userHealth >= userMaxHealth)
                                    {
                                        userHealth = userMaxHealth;
                                    }
                                    displayHealth(userHealth, userMaxHealth, 2, 13);
                                    ConsoleEx.Write("Your health was regenerated by 30!", 40, textX, textY, ConsoleColor.White);
                                    ConsoleEx.Sleep(1400);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                                }
                                else if (Game.potions[choice].name == PotionIDs.Weak.name)
                                {
                                    enemy.isWeak = true;
                                    ConsoleEx.Write("You have weakened the enemy!", 40, textX, textY, ConsoleColor.White);
                                    ConsoleEx.Sleep(1400);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                                }
                                else if (Game.potions[choice].name == PotionIDs.Distract.name)
                                {
                                    enemy.isDistract = true;
                                    ConsoleEx.Write("You have distracted the enemy!", 40, textX, textY, ConsoleColor.White);
                                    ConsoleEx.Sleep(1400);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                                }

                                Game.RemovePotion(choice);
                            }
                        }
                    }
                    else if (choice == 2)
                    {
                        if (enemy.wild == false)
                        {
                            // Nuh uh
                            ConsoleEx.Write("You cannot flee from this battle!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                        }
                        else
                        {
                            // Yuh huh
                            ConsoleEx.Write("Fled away from the enemy!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                            Screen.Clear();
                            return 2;
                        }
                    }

                    if (enemy.isWeak && wasAttacking && currentHealth > 0)
                    {
                        if (weakTick >= WEAK_TIMER)
                        {
                            enemy.isWeak = false;
                            ConsoleEx.Write("The enemy is not longer weak!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                        }
                        else
                        {
                            weakTick++;
                        }
                    }

                    if (enemy.isDistract && wasAttacking && currentHealth > 0)
                    {
                        if (distractTick >= DISTRACT_TIMER)
                        {
                            enemy.isDistract = false;
                            ConsoleEx.Write("The enemy is not longer weak!", 40, textX, textY, ConsoleColor.White);
                            ConsoleEx.Sleep(1500);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                        }
                        else
                        {
                            distractTick++;
                        }
                    }

                    wasAttacking = false;

                    // If either enemy or player health is down
                    if (currentHealth <= 0 || userHealth <= 0)
                    {
                        enemy.isWeak = false;
                        enemy.isDistract = false;
                        fin = true;
                        break;
                    }
                }

                // Did the player die?
                if (userHealth <= 0)
                {
                    Screen.Clear();
                    ConsoleEx.Write(gmoverGfx, 0, 6, 3, ConsoleColor.Red);

                    ConsoleEx.Sleep(1000);

                    Console.ForegroundColor = ConsoleColor.Cyan;
                    ConsoleEx.Write("Try again?", 0, 16, Screen.Height - 5);

                    int choice = ConsoleEx.Choice(["Yes", "No"], 18, Screen.Height - 3);

                    userHealth = oldHealth;

                    if (choice == 1)
                    {
                        return 1;
                    }

                    currentHealth = enemy.health;
                    fin = false;

                    // We lost so... TRY AGAIN (and get good please...)
                }
                // Did the enemy die?
                else if (currentHealth <= 0)
                {
                    // Make sure we aint losing xp for no reason
                    if (currentXp <= 0)
                    {
                        currentXp = 0;
                    }

                    // Add the XP to the user XP
                    userExp += (currentXp / 2) + 2 + enemy.bonus;

                    Game.Money += enemy.award;

                    // Victory!!!!!!!
                    ConsoleEx.Write("You have defeated " + getName(enemy, false) + "!", 40, textX, textY, ConsoleColor.White);
                    ConsoleEx.Sleep(2000);
                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                    if (enemy.wild == false && enemy.defeatMsg != null)
                    {
                        ConsoleEx.Write(enemy.name.ToUpper() + ": " + enemy.defeatMsg, 40, textX, textY, ConsoleColor.White);
                        ConsoleEx.Sleep(2000);
                        ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                    }

                    ConsoleEx.Write("You have gained " + (currentXp / 2) + " XP!\nand £" + enemy.award + "!", 40, textX, textY, ConsoleColor.White);
                    if (userExp < 100)
                    {
                        ConsoleEx.Write("\nCurrently " + (100 - userExp) + " XP until the next level.", 40, textX, textY + 2, ConsoleColor.White);
                    }
                    ConsoleEx.Sleep(1400);
                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                    Game.enemiesKilled++;

                    LevelUp();

                    return 0; // We won so we can break through the battle loop
                }
                else
                {
                    throw new Exception("I DON'T KNOW!!!!!!!!!!!\nMake sure one dies.");
                }
            }

            throw new Exception("should not reach here.");
            return -1;
        }

        private static void LevelUp()
        {
            if (userExp < 100)
            {
                // no
                return;
            }

            userExp = userExp % 100;
            userLevel += 1;

            ConsoleEx.Write("You have reached 100 XP!\nYou are now on Level " + userLevel + "!", 40, textX, textY, ConsoleColor.Green);
            ConsoleEx.Sleep(2000);
            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

            ConsoleEx.WriteLine("Choose what you want to upgrade:", 40, textX, textY, ConsoleColor.Green);
            int choice = ConsoleEx.Choice(["Health by +50", "Critical Chance by +2"], textX, textY + 1);
            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

            if (choice == 0)
            {
                userMaxHealth += 50;
                userHealth = userMaxHealth;
                displayHealth(userHealth, userMaxHealth, 2, 13);
                ConsoleEx.Write("Your health is now " + userMaxHealth, 40, textX, textY, ConsoleColor.White);
            }
            else if (choice == 1)
            {
                userChance += 2;
                ConsoleEx.Write("Your critical chance is now " + userChance, 40, textX, textY, ConsoleColor.White);
            }
            userHealth = userMaxHealth;
            ConsoleEx.Sleep(1800);
            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
        }
    }
}


