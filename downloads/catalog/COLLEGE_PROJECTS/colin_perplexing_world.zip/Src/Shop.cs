﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public static class Shop
    {
        static int textX = 3;
        static int textY = Screen.Height - 5;

        static int textLength = 41;
        static int textLines = 5;

        static string shopgfx = @"
           x
.-. _______|
|=|/     /  \
| |_____|_""_|
|_|_[X]_|____|";

        private static Weapon[] weaponList = [Weapons.StoneSword, Weapons.IronSword, Weapons.DiamondSword];
        private static PotionID[] potionList = [PotionIDs.Weak, PotionIDs.Distract, PotionIDs.Heal];

        static bool gotStarPiece = false;

        static int POTION_COST = 250;

        private static void refreshMoney()
        {
            ConsoleEx.ClearRect(2, 13, 12, 1);
            ConsoleEx.Write("Money: £" + Game.Money, 0, 2, 13, ConsoleColor.Yellow);
        }

        public static void Do()
        {
            // Display shop
            ConsoleEx.Write(shopgfx, 0, 15, 3, ConsoleColor.White);

            // Display a nice little border.
            ConsoleEx.ForegroundColor = ConsoleColor.Cyan;
            ConsoleEx.WriteSquare(textX - 1, textY - 1, textLength, textLines);

            refreshMoney();

            int state = 0;
            int choice = 0;
            while (true)
            {
                ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                switch (state)
                {
                    case 0:
                        {
                            ConsoleEx.WriteLine("Welcome to the shop! How can I help you?", 40, textX, textY, ConsoleColor.Yellow);
                            if (gotStarPiece)
                            {
                                choice = ConsoleEx.Choice(["Buy weapons", "Buy magic", "Talk", "Exit"], textX, textY + 1);
                            }
                            else
                            {
                                choice = ConsoleEx.Choice(["Buy weapons", "Buy magic", "Buy Star Piece", "Exit"], textX, textY + 1);
                            }
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            // States and choice + 1 are the same
                            state = choice + 1;

                            if (choice == 3)
                            {
                                Screen.Clear();
                                return;
                            }

                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            break;
                        }
                    case 1:
                        {
                            List<string> weaponChoice = new List<string>();
                            int i = 0;
                            for (i = 0; i < weaponList.Length; i++)
                            {
                                //Console.Write("is entry {0} null?", i);
                                if (weaponList[i] == null)
                                {
                                    //Console.WriteLine(" yes");
                                    break;
                                }
                                weaponChoice.Add(weaponList[i].name + " (£" + weaponList[i].cost + ")");
                            }
                            int backIdx = i;
                            weaponChoice.Add("Back");

                            // If no weapons available
                            if (backIdx == 0)
                            {
                                Screen.MoveCursorBelow();
                                throw new Exception("No weapons on stock");
                            }

                            ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
                            choice = ConsoleEx.Choice(weaponChoice.ToArray(), textX, textY);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                            if (choice != backIdx)
                            {
                                // do they have enough
                                if (weaponList[choice].cost <= Game.Money)
                                {
                                    //yes
                                    int chosen = choice;
                                    ConsoleEx.WriteLine("Are you sure?", 40, textX, textY, ConsoleColor.Yellow);
                                    choice = ConsoleEx.Choice(["Yes", "No"], textX, textY + 1);
                                    ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                    if (choice == 0)
                                    {
                                        List<string> weaponRidOf = new List<string>();
                                        for (i = 0; i < Game.weapons.Length; i++)
                                        {
                                            //Console.Write("is entry {0} null?", i);
                                            if (Game.weapons[i] == null)
                                            {
                                                //Console.WriteLine(" yes");
                                                break;
                                            }
                                            weaponRidOf.Add(Game.weapons[i].name);
                                        }
                                        int emptySlot = i;

                                        // if full inventory
                                        if (emptySlot >= Game.weapons.Length)
                                        {
                                            ConsoleEx.WriteLine("Choose what to get rid of:", 40, textX, textY, ConsoleColor.Yellow);
                                            choice = ConsoleEx.Choice(weaponRidOf.ToArray(), textX, textY + 1);
                                            Game.weapons[choice] = weaponList[chosen];
                                        }
                                        else
                                        {
                                            Game.weapons[emptySlot] = weaponList[chosen];
                                        }

                                        ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                        Game.Money -= weaponList[choice].cost;
                                        refreshMoney();
                                        ConsoleEx.WriteLine("You have purchased\n" + weaponList[chosen].name, 40, textX, textY, ConsoleColor.Yellow);
                                        ConsoleEx.Sleep(1200);
                                    }
                                }
                                else
                                {
                                    //no
                                    ConsoleEx.WriteLine("You don't have enough for\n" + weaponList[choice].name, 40, textX, textY, ConsoleColor.Yellow);
                                    ConsoleEx.Sleep(1200);
                                }
                            }

                            state = 0;
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            break;
                        }

                    case 2:
                        {
                            List<string> potionChoice = new List<string>();
                            int i = 0;
                            for (i = 0; i < potionList.Length; i++)
                            {
                                //Console.Write("is entry {0} null?", i);
                                if (potionList[i] == null)
                                {
                                    //Console.WriteLine(" yes");
                                    break;
                                }
                                potionChoice.Add(potionList[i].name + " (£" + POTION_COST + ")");
                            }
                            int backIdx = i;
                            potionChoice.Add("Back");

                            // If no weapons available
                            if (backIdx == 0)
                            {
                                Screen.MoveCursorBelow();
                                throw new Exception("No potions on stock");
                            }

                            ConsoleEx.ForegroundColor = ConsoleColor.Yellow;
                            choice = ConsoleEx.Choice(potionChoice.ToArray(), textX, textY);
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                            if (choice != backIdx)
                            {
                                if (!Game.HasPotion(potionList[choice]))
                                {
                                    // do they have enough
                                    if (POTION_COST <= Game.Money)
                                    {
                                        //yes
                                        int chosen = choice;
                                        ConsoleEx.WriteLine("Are you sure?", 40, textX, textY, ConsoleColor.Yellow);
                                        choice = ConsoleEx.Choice(["Yes", "No"], textX, textY + 1);
                                        ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                        if (choice == 0)
                                        {
                                            for (i = 0; i < Game.potions.Length; i++)
                                            {
                                                //Console.Write("is entry {0} null?", i);
                                                if (Game.potions[i] == null)
                                                {
                                                    //Console.WriteLine(" yes");
                                                    break;
                                                }
                                            }
                                            int empty = i;
                                            potionChoice.Add("Back");

                                            Game.potions[empty] = potionList[chosen];

                                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                            Game.Money -= POTION_COST;
                                            refreshMoney();
                                            ConsoleEx.WriteLine("You have purchased\n" + potionList[choice].name, 40, textX, textY, ConsoleColor.Yellow);
                                            ConsoleEx.Sleep(1200);
                                        }
                                    }
                                    else
                                    {
                                        //no
                                        ConsoleEx.WriteLine("You don't have enough for \n" + weaponList[choice].name, 40, textX, textY, ConsoleColor.Yellow);
                                        ConsoleEx.Sleep(1200);
                                    }
                                }
                                else
                                {
                                    ConsoleEx.WriteLine("You already have this potion!", 40, textX, textY, ConsoleColor.Yellow);
                                    ConsoleEx.Sleep(1200);
                                }
                            }

                            state = 0;
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            break;
                        }
                    case 3:
                        {
                            // if got star piecr from shop keeper
                            if (!gotStarPiece)
                            {
                                // talk
                                ConsoleEx.WriteLine("Oh is that so? That will be £500!", 40, textX, textY, ConsoleColor.Yellow);
                                choice = ConsoleEx.Choice(["Yes", "No"], textX, textY + 1);

                                if (choice == 0)
                                {
                                    if (500 <= Game.Money)
                                    {
                                        Game.Money -= 500;
                                        refreshMoney();
                                        gotStarPiece = true;

                                        Game.AddStarPiece();
                                    }
                                    else
                                    {
                                        ConsoleEx.WriteLine("You don't have enough money for\nthis.", 40, textX, textY, ConsoleColor.Yellow);
                                        ConsoleEx.Sleep(1200);
                                    }
                                }
                            }
                            else
                            {
                                // otherwise give it to them
                                ConsoleEx.WriteLine("Back in 1901, when this world was made,\nI was hired as the *only* person to sell\nthings at the *only* shop available!", 40, textX, textY, ConsoleColor.Yellow);
                                ConsoleEx.Sleep(2000);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);

                                ConsoleEx.WriteLine("And let me tell you the amount of\ncustomers that were coming were over\nmillions! I was in great disbelief!\nMy items are not that special either...", 40, textX, textY, ConsoleColor.Yellow);
                                ConsoleEx.Sleep(4025);
                                ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            }

                            state = 0;
                            ConsoleEx.ClearRect(textX, textY, textLength, textLines);
                            break;
                        }
                }
            }
        }

    }
}
