﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class TitleScene
    {
        private static string logoName = @"
 ______   ______   __       __   __   __    
/\  ___\ /\  __ \ /\ \     /\ \ /\ ""-.\ \   
\ \ \____\ \ \_\ \\ \ \____\ \ \\ \ \-.  \  
 \ \_____\\ \_____\\ \_____\\ \_\\ \_\\""\_\ 
  \/_____/ \/_____/ \/_____/ \/_/ \/_/ \/_/ ";

        private static string nicePic = @"    /
O===[====================-
    \
";

        private int userChoice = 0;
        public int Choice { get { return userChoice; } }

        private static string[] titleChoice = [
            "Start Game",
            "How do I play?",
            "Credits",
            "Exit",
        ];
        public void Run()
        {
            // Fancy logo
            ConsoleEx.Write(logoName, 0, 2, 0, ConsoleColor.Cyan);

            // Ugly text :)
            ConsoleEx.Write("IN THE PERPLEXING WORLD", 0, 11, 6, ConsoleColor.DarkCyan);

            // Picture here
            ConsoleEx.Write(nicePic, 0, 12, 9, ConsoleColor.White);

            // Inform the user
            ConsoleEx.Write("Use Arrow Keys or WASD to choose.", 0, 8, 19, ConsoleColor.Green);
            ConsoleEx.Write("Press ENTER/SPACE to select.", 0, 10, 20, ConsoleColor.Green);

            // Clean up the colour
            ConsoleEx.ForegroundColor = ConsoleColor.Gray;

            // What do they choose???
            userChoice = ConsoleEx.Choice(titleChoice, 16, 14);
        }
    }
}
