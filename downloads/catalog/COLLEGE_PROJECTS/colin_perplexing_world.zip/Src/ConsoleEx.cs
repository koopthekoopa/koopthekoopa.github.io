﻿using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace ProjRPG
{
    /**
     * Console Extra
     * A class full of more cooler functions for the Console!
     * (I'm scared it might be a bit unoptimized making it a bit slow)
     */
    public static class ConsoleEx
    {
        // Better ForegroundColor to fix racing conditions.
        public static ConsoleColor ForegroundColor
        {
            set
            {
                while (Console.ForegroundColor != value)
                {
                    Console.ForegroundColor = value;
                }
            }
            get
            {
                return Console.ForegroundColor;
            }
        }

        private static int BLOCK_LAG_FIX_VALUE = 20;

        public static ConsoleKey ReadKey()
        {
            // No point of this function to be honest. Was originally to fix a bug but made it worse so it's now a wrapper.
            ConsoleKeyInfo info = Console.ReadKey(true);
            return info.Key;
        }

        private static ConsoleKey skipKey = ConsoleKey.Enter;
        private static bool skipped = false;
        public static bool Skipped { get { return skipped; } }
        private static void SKIPTHREAD()
        {
            while (ReadKey() != skipKey) {}
            skipped = true;
        }
        public static void CreateSkipThread(ConsoleKey key = ConsoleKey.Enter)
        {
            skipped = false;
            skipKey = key;

            Task task = Task.Run(SKIPTHREAD);
        }
        public static void RevertSkipThread()
        {
            skipped = false;
        }

        public static void ChangeColor(ConsoleColor color)
        {
            while (ForegroundColor != color) { ForegroundColor = color; }
        }

        public static void ClearRect(int left = 0, int top = 0, int right = -1, int bottom = -1)
        {
            // We are changing the Cursor position, so backup the previous position!!
            int prevLeft = Console.CursorLeft;
            int prevTop = Console.CursorTop;

            // Fix the invalid params
            if (right < 0)
            {
                right = Console.BufferWidth;
            }
            if (bottom < 0)
            {
                bottom = Console.BufferHeight;
            }

            // Write a blank character (space)
            for (int y = top; y < top + bottom; y++)
            {
                for (int x = left; x < left + right; x++)
                {
                    Console.CursorLeft = x;
                    Console.CursorTop = y;
                    Console.Write(" ");
                }
            }

            // Welcome back, previous position!!
            Console.CursorLeft = prevLeft;
            Console.CursorTop = prevTop;
        }

        public static void Write(string text, int ms = 0, int left = -1, int top = -1, ConsoleColor color = ConsoleColor.Gray)
        {
            ForegroundColor = color;

            if (left >= 0)
            {
                Console.CursorLeft = left;
            }
            if (top >= 0)
            {
                Console.CursorTop = top;
            }
            for (int i = 0; i < text.Length; i++)
            {
                if (skipped) return;

                // Make sure new line doesn't screw it up
                if (ms == 0)
                {
                    foreach (string entry in text.Split("\n"))
                    {
                        Console.Write(entry.Replace("\r", ""));
                        Console.CursorTop++;
                        Console.CursorLeft = left;
                    }
                    return;
                }
                else
                {
                    if (text[i] == '\n')
                    {
                        Console.CursorTop++;
                        Console.CursorLeft = left;
                    }
                    // Ignore Window's disgraceful line escape.
                    else if (text[i] != '\r')
                    {
                        Console.Write(text[i]);
                        Sleep(ms);
                    }
                }
            }
        }

        public static void WriteLine(string text, int ms = 0, int left = -1, int top = -1, ConsoleColor color = ConsoleColor.Gray)
        {
            Write(text, ms, left, top);
            Console.WriteLine();
        }

        // Sleep function but you can skip it (theres a better way of doing this so I heard)
        public static void Sleep(int ms)
        {
            for (int i = 0; i < ms / 16; i++)
            {
                if (skipped) return;
                new System.Threading.ManualResetEvent(false).WaitOne(1);
            }
        }
        public static void WriteSquare(int left, int top, int right, int bottom, bool onlyOutline = true)
        {
            for (int y = top; y < top + bottom + 2; y++)
            {
                for (int x = left; x < left + right + 2; x++)
                {
                    // Write a """pixel""" on the position
                    Console.CursorLeft = x;
                    Console.CursorTop = y;
                    Console.Write("#");
                }
            }

            // Clear the boundary of the box if we want just the outline
            if (onlyOutline)
                ClearRect(left + 1, top + 1, right, bottom);
        }

        public static int Choice(string[] choices, int left = -1, int top = -1)
        {
            int chose = 0;

            // Fix invalid parameters
            if (left < 0)
            {
                left = Console.CursorLeft;
            }
            if (top < 0)
            {
                top = Console.CursorTop;
            }

            // Print the choices on console
            for (int i = 0; i < choices.Length; i++)
            {
                Write(choices[i], 0, left + 2, top + i, Console.ForegroundColor);
            }

            // HACK: make EVERYTHING not freak out...
            int aaaa = 0;
            //Sleep(BLOCK_LAG_FIX_VALUE);
            while (aaaa++ < ((BLOCK_LAG_FIX_VALUE / 2) + 3)) { }

            // Make the cursor not invisible at first by drawing it
            Write(">", 0, left, top + chose, ConsoleColor.White);

            while (true)
            {
                bool pressed = false;
                bool pressedEnter = false;

                // The cursor is BOTHERING me
                Console.CursorLeft = 0;
                Console.CursorTop = 0;

                if (Console.KeyAvailable)
                {
                    switch (ReadKey())
                    {
                        // Pressed down
                        case ConsoleKey.S:
                        case ConsoleKey.DownArrow:
                            {
                                chose += chose >= choices.Length - 1 ? 0 : 1;
                                pressed = true;
                                break;
                            }
                        // Pressed up
                        case ConsoleKey.W:
                        case ConsoleKey.UpArrow:
                            {
                                chose -= chose <= 0 ? 0 : 1;
                                pressed = true;
                                break;
                            }
                        // Pressed enter
                        case ConsoleKey.Spacebar:
                        case ConsoleKey.Enter:
                            {
                                pressedEnter = true;
                                break;
                            }
                    }

                    // HACK (alt): make EVERYTHING not freak out...
                    //Task.Delay(BLOCK_LAG_FIX_VALUE).Wait();
                    aaaa = 0;
                    while (aaaa++ < 10) { }
                }

                // If we pressed a button, update the cursor
                if (pressed)
                {
                    ClearRect(left, top, 1, choices.Length);
                    Write(">", 0, left, top + chose, Console.ForegroundColor);
                }
                // If we pressed enter, we're done
                else if (pressedEnter)
                {
                    Write(" ", 0, left, top + chose, Console.ForegroundColor);
                    break;
                }
            }

            // Return the chosen option
            return chose;
        }
    }
}
