﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class Enemy
    {
        public int health;
        public string name;
        public string art;
        public string defeatMsg;
        public bool wild = false;
        public Weapon[] weapons;
        public bool isWeak = false;
        public bool isDistract = false;
        public int award = 150;
        public int bonus = 10;
    }
    public static class Enemies
    {
        public static Enemy Guards = new Enemy
        {
            health = 95,
            name = "The Guards",
            art = @"      .-.        .-.
    __|=|__    __|=|__
   (_/`-`\_)  (_/`-`\_)
   //\___/\\  //\___/\\
   <>/   \<>  <>/   \<>
    \|_._|/    \|_._|/
     <_I_>      <_I_>
      |||        |||
     /_|_\      /_|_\",
            defeatMsg = "Woah-ho you really \npack a punch there, don't you?",
            weapons = [Weapons.GuardSword],
        };

        public static Enemy CaveExp0 = new Enemy
        {
            health = 100,
            name = "Cave Explorer",
            art = @"          .-.
        __|=|__
       (_/`-`\_)
       //\___/\\
       <>/   \<>
        \|_._|/
         <_I_>
          |||
         /_|_\",
            defeatMsg = "Damn it!\nI was close to victory!",
            weapons = [Weapons.CaveExpWeapon0],
            bonus = 50,
        };

        public static Enemy CaveExp1 = new Enemy
        {
            health = 110,
            name = "Cave Explorer",
            art = @"          .-.
        __|=|__
       (_/`-`\_)
       //\___/\\
       <>/   \<>
        \|_._|/
         <_I_>
          |||
         /_|_\",
            defeatMsg = "Hey you are pretty\n good at this!",
            weapons = [Weapons.CaveExpWeapon0, Weapons.CaveExpWeapon1],
            bonus = 50,
        };

        public static Enemy CaveExp2 = new Enemy
        {
            health = 135,
            name = "Cave Explorer",
            art = @"          .-.
        __|=|__
       (_/`-`\_)
       //\___/\\
       <>/   \<>
        \|_._|/
         <_I_>
          |||
         /_|_\",
            defeatMsg = "Hmm not bad...",
            weapons = [Weapons.CaveExpWeapon0, Weapons.CaveExpWeapon2],
            award = 250,
            bonus = 75,
        };

        public static Enemy TheKing = new Enemy
        {
            health = 550,
            name = "The King",
            art = @"         _.+._
       (^\/^\/^)
        \@*@*@/
        {_____}
       ///""""""\\\
       (/6   6\)
        ||=^=||
        \\\\///
         \\///
          `)/",
            defeatMsg = "Owww... Fine! Take your friend!\nI don't care anymore!!",
            weapons = [Weapons.StoneSword, Weapons.CaveExpWeapon2, Weapons.IronSwordBad],
            award = 250,
            bonus = 1200,
        };

        public static Enemy Dragon = new Enemy
        {
            health = 60,
            name = "dragon",
            art = @"          \\ \\           
          ) \\ \\    _p_ 
          )^\))\))  /  *\ 
           \_|| || / /^`-' 
  __       -\ \\--/ / 
<'  \\___/   ___. )'
     `====\ )___/\\ 
          //     `""
          \\    /  \",
            weapons = [Weapons.DragonBite],
            wild = true,
            award = 70,
            bonus = 25,
        };

        public static Enemy Goblin = new Enemy
        {
            health = 85,
            name = "goblin",
            art = @"          ,      ,
         /(.-""-.)\
     |\  \/      \/  /|
     | \ / =.  .= \ / |
     \( \   o\/o   / )/
      \_, '-/  \-' ,_/
        /   \__/   \
        \ \__/\__/ /
      ___\ \|--|/ /___
    /`    \      /    `\
   /       '----'       \",
            weapons = [Weapons.WoodenSword],
            wild = true,
            award = 95,
            bonus = 50,
        };

        public static Enemy Bat = new Enemy
        {
            health = 35,
            name = "bat",
            art = @"


     (_    ,_,    _) 
     / `'--) (--'` \
    /  _,-'\_/'-,_  \
   /.-'     ""     '-.\",
            weapons = [Weapons.DragonBite],
            wild = true,
            award = 40,
        };

        public static Enemy[] wildEnms = [Bat, Dragon, Bat, Goblin, Bat]; // Why more bats? They're a common enemy and wanna trick the Random generator system.
    }
}
