﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public static class Map
    {
        static Maps.Name currentMap = Maps.Name.PROLOGUE;

        static string[] prlgBattlePro =
        {
            "Are you a new person that somehow\nstumbled across this world?",
            "If that's the case, Welcome to the\nworld that perplexes people!",
            "Are you ready to see the exciting\nthings that await?",
            "HAH! Not quite yet! You must show us how\ntough you are before entering in.",
            "This place is pretty rough and you need\nall of your strength.",
            "So come on!!! No Snoozing!! Get ready!",
        };

        static string[] prlgBattleEpiWon =
        {
            "Oh my god! Finally! Someone that\nis powerful enough to enter in!",
            "Maybe even powerful to take on\nthe King of this World-",
            "Oh err hehe I mean, Well done, newcomer.\nYou have proved to us that you are ready.",
            "You may now pass through the gate."
        };
        static string[] prlgBattleEpiLost =
        {
            "Sorry, Pal. You are not ready yet to pass\nthrough here and enter in this world."
        };

        static int px, py;
        static int oldpx, oldpy;

        private static void RefreshPlayerDisplay()
        {
            // Refresh player
            ConsoleEx.Write(entry.mapLayout[oldpy][oldpx].ToString(), 0, oldpx + 1, oldpy + 1);
            ConsoleEx.Write("O", 0, px + 1, py + 1, ConsoleColor.Cyan);
        }
        public static void RefreshMapDisplay()
        {
            // Refresh player
            int y = 1;
            Screen.Clear();
            foreach (string row in entry.mapLayout)
            {
                ConsoleEx.Write(row, 0, 1, y++, ConsoleColor.White);
            }
            ConsoleEx.Write(entry.name, 0, 0, Screen.Height + 1, ConsoleColor.Cyan);
            RefreshPlayerDisplay();
        }

        static MapEntry entry = null;
        public static void Init()
        {
            currentMap = 0;
        }
        public static void Prepare(MapEntry nEntry, bool startPos = true)
        {
            // Prepare the map
            entry = nEntry;

            if (startPos)
            {
                px = entry.startX;
                py = entry.startY;
            }

            oldpx = px;
            oldpy = py;

            int y = 1;
            foreach (string row in entry.mapLayout)
            {
                ConsoleEx.Write(row, 0, 1, y++, ConsoleColor.White);
            }
            RefreshMapDisplay();
        }
        public static bool prevEnc = false;
        public static bool doneKingGuards = false;
        public static void CheckWild()
        {
            // Check for wild life
            if (doneKingGuards)
            {
                Random rng = new Random();
                if (rng.NextDouble() <= 0.035)
                {
                    if (prevEnc)
                    {
                        prevEnc = false;
                    }
                    else
                    {
                        ConsoleEx.Write("Enemy Encountered!!", 0, 0, Screen.Height + 1, ConsoleColor.Red);
                        ConsoleEx.Sleep(1200);
                        Battle.Do(Enemies.wildEnms[rng.Next(0, Enemies.wildEnms.Length)]);

                        RefreshMapDisplay();
                        prevEnc = true;
                    }
                }
            }
        }
        public static bool NearChar(char ch)
        { 
            // Near a character in the map
            if (entry.mapLayout[py - 1][px] == ch || entry.mapLayout[py + 1][px] == ch || entry.mapLayout[py][px - 1] == ch || entry.mapLayout[py][px + 1] == ch)
            {
                return true;
            }
            return false;
        }
        public static int Run()
        {
            // The game logic
            bool defeatCE0 = false;
            bool defeatCE1 = false;
            bool defeatCE2 = false;

            bool enterKing = false;

            bool trigStarPieceLevel = false;

            bool chatWithGuards = false;

            bool donePuzzle = false;

            Maps.FieldName fieldMap = Maps.FieldName.FIELD_BOTTOM;
            Maps.CaveName caveMap = Maps.CaveName.CAVE_MIDDLE;

            RefreshPlayerDisplay();
            while (true)
            {
                if (Console.KeyAvailable)
                {
                    ConsoleKey key = ConsoleEx.ReadKey();
                    switch (key)
                    {
                        // Why is the code so bad?
                        // ...Rushed!
                        case ConsoleKey.W:
                        case ConsoleKey.UpArrow:
                            {
                                if (py > 0)
                                {
                                    if (entry.mapLayout[py - 1][px] != '#'
                                        && entry.mapLayout[py - 1][px] != '='
                                        && entry.mapLayout[py - 1][px] != '0' 
                                        && entry.mapLayout[py - 1][px] != '/')
                                    {
                                        oldpx = px;
                                        oldpy = py;
                                        py--;
                                    }
                                }

                                break;
                            }
                        case ConsoleKey.S:
                        case ConsoleKey.DownArrow:
                            {
                                if (py < entry.height - 1)
                                {
                                    if (entry.mapLayout[py + 1][px] != '#'
                                        && entry.mapLayout[py + 1][px] != '='
                                        && entry.mapLayout[py + 1][px] != '0'
                                        && entry.mapLayout[py + 1][px] != '/') {
                                        oldpx = px;
                                        oldpy = py;
                                        py++;
                                    }
                                }

                                break;
                            }
                        case ConsoleKey.A:
                        case ConsoleKey.LeftArrow:
                            {
                                if (px > 0)
                                {
                                    if (entry.mapLayout[py][px - 1] != '#'
                                        && entry.mapLayout[py][px - 1] != '='
                                        && entry.mapLayout[py][px - 1] != '0'
                                        && entry.mapLayout[py][px - 1] != '/')
                                    {
                                        oldpx = px;
                                        oldpy = py;
                                        px--;
                                    }
                                }

                                break;
                            }
                        case ConsoleKey.D:
                        case ConsoleKey.RightArrow:
                            {
                                if (px < entry.width - 1)
                                {
                                    if (entry.mapLayout[py][px + 1] != '#'
                                        && entry.mapLayout[py][px + 1] != '='
                                        && entry.mapLayout[py][px + 1] != '0'
                                        && entry.mapLayout[py][px + 1] != '/')
                                    {
                                        oldpx = px;
                                        oldpy = py;
                                        px++;
                                    }
                                }

                                break;
                            }
                    }
                    RefreshPlayerDisplay();

                    switch(currentMap)
                    {
                        // PROLOGUE
                        case Maps.Name.PROLOGUE:
                            {
                                if (py <= 7)
                                {
                                    Game.TextBoxDo(prlgBattlePro);

                                    Screen.Clear();
                                    int result = Battle.Do(Enemies.Guards);
                                    Battle.userHealth = Battle.userMaxHealth;

                                    // Won
                                    if (result == 0)
                                    {
                                        fieldMap = Maps.FieldName.FIELD_BOTTOM;
                                        currentMap = Maps.Name.FIELD;

                                        RefreshMapDisplay();

                                        Game.TextBoxDo(prlgBattleEpiWon);

                                        Prepare(Maps.field0);
                                    }
                                    // Lost
                                    else if (result == 1) {
                                        py += 2;

                                        RefreshMapDisplay();

                                        Game.TextBoxDo(prlgBattleEpiLost);
                                        RefreshMapDisplay();
                                    }
                                    else
                                    {
                                        throw new Exception("invalid battle return... got " + result);
                                    }

                                    /* (FOR DEBUGGING)
                                    fieldMap = Maps.FieldName.FIELD_BOTTOM;
                                    currentMap = Maps.Name.FIELD;

                                    RefreshMapDisplay();
                                    Prepare(Maps.field0);*/
                                }
                                break;
                            }
                        // FIELD
                        case Maps.Name.FIELD:
                            {
                                switch(fieldMap)
                                {
                                    // FIELD BOTTOM
                                    case Maps.FieldName.FIELD_BOTTOM:
                                        {
                                            if (py <= 0)
                                            {
                                                fieldMap = Maps.FieldName.FIELD_MIDDLE;
                                                px = Screen.Width / 2;
                                                py = Screen.Height - 2;
                                                Prepare(Maps.field1, false);
                                                break;
                                            }
                                            break;
                                        }
                                    // FIELD MIDDLE
                                    case Maps.FieldName.FIELD_MIDDLE:
                                        {
                                            if (py >= Screen.Height - 1)
                                            {
                                                fieldMap = Maps.FieldName.FIELD_BOTTOM;
                                                px = Screen.Width / 2;
                                                py = 1;
                                                Prepare(Maps.field0, false);
                                                break;
                                            }
                                            else if (py <= 0)
                                            {
                                                if (enterKing)
                                                {
                                                    currentMap = Maps.Name.KING;
                                                    Prepare(Maps.field2);
                                                }
                                                else
                                                {
                                                    fieldMap = Maps.FieldName.FIELD_TOP;
                                                    px = Screen.Width / 2;
                                                    py = Screen.Height - 2;
                                                    Prepare(Maps.field2, false);
                                                }
                                                break;
                                            }
                                            else if (px <= 0)
                                            {
                                                if (!doneKingGuards)
                                                {
                                                    Game.TextBoxDo(["You cannot enter in yet...", "First, talk to the guards on the\ntop field."]);
                                                    px++;
                                                    RefreshMapDisplay();
                                                }
                                                else
                                                {
                                                    currentMap = Maps.Name.CAVERN;
                                                    caveMap = Maps.CaveName.CAVE_MIDDLE;
                                                    px = Screen.Width - 2;
                                                    py = Screen.Height / 2;
                                                    Prepare(Maps.cavern0, false);
                                                    break;
                                                }
                                            }
                                            else if (px >= Screen.Width - 2)
                                            {
                                                if (!doneKingGuards)
                                                {
                                                    Game.TextBoxDo(["You cannot enter in yet...", "First, talk to the guards on the\ntop field."]);
                                                    px--;
                                                    RefreshMapDisplay();
                                                }
                                                else
                                                {
                                                    currentMap = Maps.Name.PUZZLE;
                                                    px = 1;
                                                    py = Screen.Height / 2;
                                                    Prepare(Maps.puzzleMap, false);
                                                    break;
                                                }
                                            }

                                            if (entry.mapLayout[py - 1][px] == '=')
                                            {
                                                if (!doneKingGuards)
                                                {
                                                    Game.TextBoxDo(["You cannot enter in yet...", "First, talk to the guards on the\ntop field."]);
                                                    py++;
                                                    RefreshMapDisplay();
                                                }
                                                else
                                                {
                                                    Screen.Clear();
                                                    Shop.Do();
                                                    py++;
                                                    RefreshMapDisplay();
                                                }
                                            }

                                            break;
                                        }
                                    // FIELD TOP
                                    case Maps.FieldName.FIELD_TOP:
                                        {
                                            if (py >= Screen.Height - 1)
                                            {
                                                if (chatWithGuards) doneKingGuards = true;
                                                fieldMap = Maps.FieldName.FIELD_MIDDLE;
                                                px = Screen.Width / 2;
                                                py = 1;
                                                Prepare(Maps.field1, false);
                                                break;
                                            }
                                            if (py <= 8)
                                            {
                                                py++;
                                                if (!doneKingGuards)
                                                {
                                                    Game.TextBoxDo(["Huh- Wha- Who are you?\nAre- Are you new here?",
                                                                    "Huh, someone that is new AND powerful\nenough to enter in this world.",
                                                                    "uhh... Welcome! It's quite chaotic in\nhere.",
                                                                    "Hmm? You are looking for your friend\nnamed \"Toby?\"",
                                                                    "Heheh glad you asked. He is trapped with\nthe king... maybe forever! Hahaa!",
                                                                    "And you are never going to see him again!",
                                                                    "Huh? You really want to see him again?\nBut I just said- oh fine.",
                                                                    "If you really want to see him again,\ndo us a favour.",
                                                                    "There are these mytserious pieces called\n'Star Pieces'. They're scattered around!",
                                                                    "Try and find all " + Game.MaxStarPieces + " of them and then you\ncan see the king and Toby!"]);
                                                    chatWithGuards = true;
                                                }
                                                else
                                                {
                                                    if (Game.StarPieces >= Game.MaxStarPieces)
                                                    {
                                                        Game.TextBoxDo(["Oh, it's you again. What do you want?",
                                                                        "What? You got all of the " + Game.MaxStarPieces +  " star pieces?!",
                                                                        "*looking at the star pieces*",
                                                                        "(How the HECK was this real?)",
                                                                        "(I just made\nit up for the\nsake of wasting his time!)",
                                                                        "(God he really IS gonna see his friend again!)",
                                                                        "*clear throat* Good job, friend.\nYou maynow pass through the gate.",
                                                                        "And then see the King to get back\nyourfriend.... *sigh*"]);
                                                        currentMap = Maps.Name.KING;
                                                        enterKing = true;
                                                        Prepare(Maps.theKing);
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        Game.TextBoxDo(["C'mon, Stop slacking! Find them."]);
                                                    }
                                                }
                                                RefreshMapDisplay();
                                            }
                                            break;
                                        }
                                }
                                CheckWild();

                                break;
                            }
                        // Puzzle map
                        case Maps.Name.PUZZLE:
                            {
                                if (px <= 0)
                                {
                                    currentMap = Maps.Name.FIELD;
                                    fieldMap = Maps.FieldName.FIELD_MIDDLE;
                                    px = Screen.Width - 2;
                                    py = Screen.Height / 2;
                                    Prepare(Maps.field1, false);
                                    break;
                                }

                                if (px >= Screen.Width - 8 && !donePuzzle)
                                {
                                    int choice = 0;

                                    Game.TextBoxDo(["Hello we are the quiz brothers,\nAnd we like to do a test on you.",
                                                    "A little... recap of what you know\nabout this world.",
                                                    "And once you have passed, I'll give\nyou this star piece that I randomly\nfound.",
                                                    "So.. Are you ready?\nGood."], 4);

                                    Game.TextBoxDo(["QUESTION NUMBER ONE", "What lever in the cavern was to\nreveal some treasure?"], 4);

                                    choice = ConsoleEx.Choice(["Upper left", "Upper right", "Bottom left", "Bottom right"], 3, Screen.Height - 4);
                                    if (choice == 2)
                                    {
                                        int answer;
                                        Game.TextBoxDo(["Correct, getting good so far...", "QUESTION NUMBER TWO", "What year exactly was this world found?"], 4);
                                        while(true)
                                        {
                                            try
                                            {
                                                ConsoleEx.Write("Enter answer as number here: ", 0, 3, Screen.Height - 4);
                                                answer = Convert.ToInt32(Console.ReadLine());
                                                break;
                                            }
                                            catch (FormatException) { continue; }
                                        }

                                        if (answer == 1901)
                                        {
                                            Game.TextBoxDo(["Hahaha yes!! Now for this one there is no\nanswer... It's just your opinion.", "Who do you think is the funniest?"], 4);
                                            ConsoleEx.Choice(["You, of course!", "Uuh the person next to you."], 3, Screen.Height - 3);
                                            Game.TextBoxDo(["I see... Anyway next question!!", "QUESTION NUMBER THREE (Final!)", "How long is the fall to this world?"], 4);
                                            choice = ConsoleEx.Choice(["Minutes", "Hours", "Years!!"], 3, Screen.Height - 4);
                                            if (choice == 1)
                                            {
                                                Game.TextBoxDo(["Well done, my guy... You have answered\nall of the questions correctly.", "I will now give you you this\nstar piece."], 4);
                                                donePuzzle = true;
                                                RefreshMapDisplay();
                                                Game.AddStarPiece();
                                            }
                                            else
                                            {
                                                Game.TextBoxDo(["Seriously?"], 4);
                                            }
                                        }
                                        else
                                        {
                                            Game.TextBoxDo(["Nope. Try and talk to someone who\nhas been here for years."], 4);
                                        }
                                    }
                                    else
                                    {
                                        Game.TextBoxDo(["That was the incorrect answer."], 4);
                                    }

                                    px--;

                                    RefreshMapDisplay();
                                }
                                break;
                            }
                        // Cavern
                        case Maps.Name.CAVERN:
                            {
                                switch(caveMap)
                                {
                                    // Main part
                                    case Maps.CaveName.CAVE_MIDDLE:
                                        {
                                            if (px >= Screen.Width - 1)
                                            {
                                                currentMap = Maps.Name.FIELD;
                                                fieldMap = Maps.FieldName.FIELD_MIDDLE;
                                                px = 1;
                                                py = Screen.Height / 2;
                                                Prepare(Maps.field1, false);
                                                break;
                                            }
                                            else if (py <= 0)
                                            {
                                                caveMap = Maps.CaveName.CAVE_ARENA;
                                                px = Screen.Width / 2;
                                                py = Screen.Height - 2;
                                                Prepare(Maps.cavern1, false);
                                                break;
                                            }
                                            else if (py >= Screen.Height - 1)
                                            {
                                                caveMap = Maps.CaveName.CAVE_PUZZLE;
                                                px = Screen.Width / 2;
                                                py = 1;
                                                Prepare(Maps.cavern2, false);
                                                break;
                                            }
                                            break;
                                        }
                                    // Arena
                                    case Maps.CaveName.CAVE_ARENA:
                                        {
                                            if (py >= Screen.Height - 1)
                                            {
                                                caveMap = Maps.CaveName.CAVE_MIDDLE;
                                                px = Screen.Width / 2;
                                                py = 1;
                                                Prepare(Maps.cavern0, false);
                                                break;
                                            }
                                            
                                            if (py <= 10 && !defeatCE0)
                                            {
                                                Game.TextBoxDo(["Hey hey where are you going?\nDon't leave me without a fight!"]);
                                                int won = Battle.Do(Enemies.CaveExp0);
                                                if (won == 0)
                                                {
                                                    defeatCE0 = true;
                                                }
                                                else
                                                {
                                                    py--;
                                                }
                                                RefreshMapDisplay();
                                            }
                                            else if (py <= 8 && !defeatCE1)
                                            {
                                                Game.TextBoxDo(["Hmm I feel like fighting...\nWhat about you? Yes, YOU!!"]);
                                                int won = Battle.Do(Enemies.CaveExp1);
                                                if (won == 0)
                                                {
                                                    defeatCE1 = true;
                                                }
                                                else
                                                {
                                                    py--;
                                                }
                                                RefreshMapDisplay();
                                            }
                                            else if (py <= 4 && !defeatCE2)
                                            {
                                                Game.TextBoxDo(["So you have come to me to obtain\none of those star pieces, huh?", "Well then... challenge me first...\nAnd it is yours!"]);
                                                int won = Battle.Do(Enemies.CaveExp2);
                                                if (won == 0)
                                                {
                                                    Game.TextBoxDo(["Well done... You have proven to me that\nyou are a grateful and skilled warrior.", "I shall now gift this to you."]);
                                                    RefreshMapDisplay();
                                                    Game.AddStarPiece();
                                                    defeatCE2 = true;
                                                }
                                                else
                                                {
                                                    py--;
                                                }
                                                RefreshMapDisplay();
                                            }
                                            break;
                                        }
                                    // Levers
                                    case Maps.CaveName.CAVE_PUZZLE:
                                        {
                                            if (py <= 0)
                                            {
                                                caveMap = Maps.CaveName.CAVE_MIDDLE;
                                                px = Screen.Width / 2;
                                                py = Screen.Height - 2;
                                                Prepare(Maps.cavern0, false);
                                                break;
                                            }

                                            // Upper left
                                            if ((py < Screen.Height / 2 && px < Screen.Height) && NearChar('/') && key == ConsoleKey.Enter)
                                            {
                                                Game.TextBoxDo(["You pull the upper left lever...", "It seemed to do nothing..."]);
                                                RefreshMapDisplay();
                                            }
                                            // Bottom left
                                            else if ((py > Screen.Height / 2 && px < Screen.Height) && NearChar('/') && key == ConsoleKey.Enter)
                                            {
                                                Game.TextBoxDo(["You pull the bottom left lever..."]);
                                                if (!trigStarPieceLevel)
                                                {
                                                    Game.AddStarPiece();
                                                }
                                                else
                                                {
                                                    Game.TextBoxDo(["It seemed to do nothing..."]);
                                                }
                                                RefreshMapDisplay();
                                            }
                                            // Upper Right
                                            else if ((py < Screen.Height / 2 && px > Screen.Height) && NearChar('/') && key == ConsoleKey.Enter)
                                            {
                                                Game.TextBoxDo(["You pull the upper right lever...", "It seemed to do nothing..."]);
                                                RefreshMapDisplay();
                                            }
                                            // Bottom right
                                            else if ((py > Screen.Height / 2 && px > Screen.Height) && NearChar('/') && key == ConsoleKey.Enter)
                                            {
                                                Game.TextBoxDo(["You pull the bottom right lever...", "It seemed to do nothing..."]);
                                                RefreshMapDisplay();
                                            }
                                            break;
                                        }
                                }

                                CheckWild();

                                break;
                            }
                            // KING PALACE!!!!
                            case Maps.Name.KING: {
                                if (entry.mapLayout[py - 1][px] == '=')
                                {
                                    Screen.Clear();
                                    Shop.Do();
                                    py++;
                                    RefreshMapDisplay();
                                }

                                if (py >= Screen.Height - 1)
                                {
                                    fieldMap = Maps.FieldName.FIELD_MIDDLE;
                                    currentMap = Maps.Name.FIELD;
                                    px = Screen.Width / 2;
                                    py = 1;
                                    Prepare(Maps.cavern0, false);
                                    break;
                                }

                                if (py < 13)
                                {
                                    // greet
                                    Game.TextBoxDo(["Haw haw! Who do we have here?\nSomeone that looks like this Toby person!",
                                                    "If that's who you are looking for,\nI'm sorry but you won't see him again!",
                                                    "TOBY: You gotta help me, Colin!",
                                                    "KING: Oh you really want him back?\nWELL THEN..."]);
                                    int won = Battle.Do(Enemies.TheKing);
                                    if (won == 0)
                                    {
                                        // he really did it...
                                        Game.TextBoxDo(["THE GUARDS: Oh my god he did it.",
                                                        "He had beaten the king...\nOh how can we thank you!",
                                                        "Huh?! you want to leave?!!\nALREADY?!",
                                                        "Err sure! hehe *sniff* I'll\nsee what I can do...",
                                                        "Oh I know! I have a secret\ntrampoline somewhere",
                                                        "That you can jump onto and\nget out of this world!",
                                                        "Sure it's critically for emergency\npurposes but... I don't really care."]);
                                        return 0;
                                    }
                                    else
                                    {
                                        // boooooo
                                        py--;
                                        RefreshMapDisplay();
                                        Game.TextBoxDo(["HAW HAW! You better hurry up and\nimprove your self, friend!",
                                                        "TOBY: Be quick, Colin!"]);
                                    }
                                }

                                break;
                            }
                    }
                }
                Screen.MoveCursorBelow();
            }

            // unreachable i know
            return 0;
        }
    }
}


