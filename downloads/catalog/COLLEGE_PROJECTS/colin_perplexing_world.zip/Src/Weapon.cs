﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class Weapon
    {
        public string name;
        public int damage;
        public double criticalChance;
        public double criticalDamage;
        public double missChance;
        public int cost = 1500;
    }

    public static class Weapons
    {
        public static Weapon WoodenSword = new Weapon
        {
            name = "Wooden Sword",
            damage = 20,
            criticalChance = 0.11,
            criticalDamage = 1.5,
            missChance = 0.1,
        };
        public static Weapon StoneSword = new Weapon
        {
            name = "Stone sword",
            damage = 22,
            criticalChance = 0.25,
            criticalDamage = 1.5,
            missChance = 0.1,
            cost = 1500,
        };
        public static Weapon IronSword = new Weapon
        {
            name = "Iron sword",
            damage = 24,
            criticalChance = 0.45,
            criticalDamage = 1.75,
            missChance = 0.1,
            cost = 2000,
        };
        public static Weapon IronSwordBad = new Weapon
        {
            name = "Iron sword",
            damage = 21,
            criticalChance = 0.4,
            criticalDamage = 1.7,
            missChance = 0.1,
            cost = 2000,
        };
        public static Weapon DiamondSword = new Weapon
        {
            name = "Diamond sword",
            damage = 30,
            criticalChance = 0.55,
            criticalDamage = 2.3,
            missChance = 0.09,
            cost = 2750,
        };
        public static Weapon GuardSword = new Weapon
        {
            name = "their Sword",
            damage = 11,
            criticalChance = 0.12,
            criticalDamage = 1.4,
            missChance = 0.30,
        };
        public static Weapon CaveExpWeapon0 = new Weapon
        {
            name = "Stone sword",
            damage = 11,
            criticalChance = 0.25,
            criticalDamage = 1.5,
            missChance = 0.2,
        };
        public static Weapon CaveExpWeapon1 = new Weapon
        {
            name = "Hand crafted bow",
            damage = 10,
            criticalChance = 0.3,
            criticalDamage = 1.2,
            missChance = 0.35,
        };
        public static Weapon CaveExpWeapon2 = new Weapon
        {
            name = "Hand crafted bow",
            damage = 12,
            criticalChance = 0.3,
            criticalDamage = 1.2,
            missChance = 0.35,
        };
        public static Weapon DragonBite = new Weapon
        {
            name = "Bite",
            damage = 8,
            criticalChance = 0.3,
            criticalDamage = 1.5,
            missChance = 0.1,
        };
    }
}
