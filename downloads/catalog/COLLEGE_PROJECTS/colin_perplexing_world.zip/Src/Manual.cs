﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public class Manual
    {
        private static string manualText = @"
 * You use the arrow keys or WASD
   to navigate around the map.

 * Keep in mind saving progress is not
  an option.







 Press RIGHT ARROW to scroll to the
 next page.";

        private static string manualText2 = @"
 Here is a list of what a letter represents:
   'O' = Your character
   '0' = Someone willing to fight!!!
   '=' = A door. Try and find one and see if
         you can open it...
   '/' = A lever. Try pressing ENTER on it.






 Press LEFT ARROW to scroll to the
 previous page.";

        public void Run()
        {
            Screen.Clear();

            // how 2 play theze game
            ConsoleEx.Write("HOW TO PLAY:", 0, 2, 2, ConsoleColor.Green);

            Console.ResetColor();
            ConsoleEx.Write(manualText, 0, 1, 4);

            ConsoleEx.Write("Press ENTER to go back to the menu.", 0, 2, 20, ConsoleColor.Green);

            while (true) {
                ConsoleKey key = ConsoleEx.ReadKey();
                if (key == ConsoleKey.LeftArrow)
                {
                    ConsoleEx.ClearRect(1, 4, Screen.Width, Screen.Height - 4);
                    ConsoleEx.Write(manualText, 0, 1, 4);
                }
                else if (key == ConsoleKey.RightArrow)
                {
                    ConsoleEx.ClearRect(1, 4, Screen.Width, Screen.Height - 4);
                    ConsoleEx.Write(manualText2, 0, 1, 4);
                }
                else
                {
                    break;
                }
            }
        }
    }
}
