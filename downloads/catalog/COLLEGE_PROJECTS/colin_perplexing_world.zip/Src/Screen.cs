﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjRPG
{
    public static class Screen
    {
        private static int s_width;
        private static int s_height;

        public static int Width { get { return s_width; } }
        public static int Height { get { return s_height; } }

        public static bool init = false;

        public static void Init(int width, int height)
        {
            // Write a square
            ConsoleEx.WriteSquare(0, 0, width, height);

            s_width = width;
            s_height = height;

            // Tell its initialized
            init = true;

            // Thats it.
        }

        public static void Clear()
        {
            ConsoleEx.ClearRect(1, 1, s_width, s_height);
            ConsoleEx.Write("###################", 0, 0, s_height + 1, ConsoleColor.Yellow); // For text on screen border
        }

        public static void MoveCursorBelow()
        {
            // This function is absolutely useless
            if (init == false) return;
            Console.CursorTop = s_height + 2;
            Console.CursorLeft = 0;
        }
    }
}
